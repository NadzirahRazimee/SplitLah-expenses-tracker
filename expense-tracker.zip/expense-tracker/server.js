// ===== SERVER.JS (Backend) ===== 
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('public')); // Serve static files

// Database setup
const db = new sqlite3.Database('./expenses.db', (err) => {
    if (err) {
        console.error('Error opening database:', err);
    } else {
        console.log('Connected to SQLite database');
        initializeDatabase();
    }
});

function initializeDatabase() {
    db.run(`
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            amount REAL NOT NULL,
            category TEXT NOT NULL,
            date TEXT NOT NULL,
            description TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    db.run(`
        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            color TEXT NOT NULL
        )
    `);

    // Insert default categories
    const defaultCategories = [
        { name: 'Food', color: '#FF6B6B' },
        { name: 'Transportation', color: '#4ECDC4' },
        { name: 'Entertainment', color: '#45B7D1' },
        { name: 'Shopping', color: '#96CEB4' },
        { name: 'Bills', color: '#FFEAA7' },
        { name: 'Healthcare', color: '#DDA0DD' },
        { name: 'Other', color: '#A8A8A8' }
    ];

    defaultCategories.forEach(category => {
        db.run(`INSERT OR IGNORE INTO categories (name, color) VALUES (?, ?)`, 
               [category.name, category.color]);
    });
}

// API Routes

// Get all expenses
app.get('/api/expenses', (req, res) => {
    db.all(`
        SELECT e.*, c.color as category_color 
        FROM expenses e 
        JOIN categories c ON e.category = c.name 
        ORDER BY e.date DESC
    `, (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json(rows);
        }
    });
});

// Add new expense
app.post('/api/expenses', (req, res) => {
    const { title, amount, category, date, description } = req.body;
    
    if (!title || !amount || !category || !date) {
        return res.status(400).json({ error: 'Missing required fields' });
    }

    db.run(`
        INSERT INTO expenses (title, amount, category, date, description) 
        VALUES (?, ?, ?, ?, ?)
    `, [title, amount, category, date, description], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json({ id: this.lastID, message: 'Expense added successfully' });
        }
    });
});

// Delete expense
app.delete('/api/expenses/:id', (req, res) => {
    const { id } = req.params;
    
    db.run('DELETE FROM expenses WHERE id = ?', [id], function(err) {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json({ message: 'Expense deleted successfully' });
        }
    });
});

// Get categories
app.get('/api/categories', (req, res) => {
    db.all('SELECT * FROM categories ORDER BY name', (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json(rows);
        }
    });
});

// Get expense statistics
app.get('/api/stats', (req, res) => {
    db.all(`
        SELECT 
            category,
            SUM(amount) as total,
            COUNT(*) as count,
            c.color
        FROM expenses e
        JOIN categories c ON e.category = c.name
        GROUP BY category
        ORDER BY total DESC
    `, (err, rows) => {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.json(rows);
        }
    });
});

// Serve the main page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 Server running on http://localhost:${PORT}`);
});