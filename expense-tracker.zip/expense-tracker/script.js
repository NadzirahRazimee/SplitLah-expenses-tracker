`class ExpenseTracker {
    constructor() {
        this.expenses = [];
        this.categories = [];
        this.chart = null;
        
        this.initializeElements();
        this.bindEvents();
        this.loadData();
    }

    initializeElements() {
        this.expenseForm = document.getElementById('expenseForm');
        this.titleInput = document.getElementById('title');
        this.amountInput = document.getElementById('amount');
        this.categorySelect = document.getElementById('category');
        this.dateInput = document.getElementById('date');
        this.descriptionInput = document.getElementById('description');
        this.expensesList = document.getElementById('expensesList');
        
        // Set today's date as default
        this.dateInput.value = new Date().toISOString().split('T')[0];
    }

    bindEvents() {
        this.expenseForm.addEventListener('submit', (e) => {
            e.preventDefault();
            this.addExpense();
        });
    }

    async loadData() {
        try {
            await this.loadCategories();
            await this.loadExpenses();
            this.updateStats();
            this.updateChart();
        } catch (error) {
            console.error('Error loading data:', error);
        }
    }

    async loadCategories() {
        const response = await fetch('/api/categories');
        this.categories = await response.json();
        
        this.categorySelect.innerHTML = '<option value="">Select category</option>';
        this.categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category.name;
            option.textContent = category.name;
            this.categorySelect.appendChild(option);
        });
    }

    async loadExpenses() {
        const response = await fetch('/api/expenses');
        this.expenses = await response.json();
        this.renderExpenses();
    }

    async addExpense() {
        const expenseData = {
            title: this.titleInput.value.trim(),
            amount: parseFloat(this.amountInput.value),
            category: this.categorySelect.value,
            date: this.dateInput.value,
            description: this.descriptionInput.value.trim()
        };

        try {
            const response = await fetch('/api/expenses', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(expenseData)
            });

            if (response.ok) {
                this.expenseForm.reset();
                this.dateInput.value = new Date().toISOString().split('T')[0];
                await this.loadExpenses();
                this.updateStats();
                this.updateChart();
            }
        } catch (error) {
            console.error('Error adding expense:', error);
        }
    }

    async deleteExpense(id) {
        if (!confirm('Are you sure you want to delete this expense?')) return;

        try {
            const response = await fetch(\`/api/expenses/\${id}\`, {
                method: 'DELETE'
            });

            if (response.ok) {
                await this.loadExpenses();
                this.updateStats();
                this.updateChart();
            }
        } catch (error) {
            console.error('Error deleting expense:', error);
        }
    }

    renderExpenses() {
        if (this.expenses.length === 0) {
            this.expensesList.innerHTML = \`
                <div style="text-align: center; padding: 40px; color: #666;">
                    <h3>No expenses yet!</h3>
                    <p>Add your first expense above to get started.</p>
                </div>
            \`;
            return;
        }

        this.expensesList.innerHTML = this.expenses.map(expense => \`
            <div class="expense-item" style="border-left-color: \${expense.category_color}">
                <div class="expense-info">
                    <h4>\${expense.title}</h4>
                    <p>\${expense.category} • \${new Date(expense.date).toLocaleDateString()}</p>
                    \${expense.description ? \`<p><em>\${expense.description}</em></p>\` : ''}
                </div>
                <div style="display: flex; align-items: center;">
                    <span class="expense-amount">$\${expense.amount.toFixed(2)}</span>
                    <button class="delete-btn" onclick="expenseTracker.deleteExpense(\${expense.id})">×</button>
                </div>
            </div>
        \`).join('');
    }

    updateStats() {
        const total = this.expenses.reduce((sum, expense) => sum + expense.amount, 0);
        const currentMonth = new Date().getMonth();
        const currentYear = new Date().getFullYear();
        
        const monthlyExpenses = this.expenses.filter(expense => {
            const expenseDate = new Date(expense.date);
            return expenseDate.getMonth() === currentMonth && 
                   expenseDate.getFullYear() === currentYear;
        }).reduce((sum, expense) => sum + expense.amount, 0);

        document.getElementById('totalExpenses').textContent = \`$\${total.toFixed(2)}\`;
        document.getElementById('monthlyExpenses').textContent = \`$\${monthlyExpenses.toFixed(2)}\`;
        document.getElementById('totalTransactions').textContent = this.expenses.length;
    }

    async updateChart() {
        try {
            const response = await fetch('/api/stats');
            const stats = await response.json();

            const ctx = document.getElementById('expenseChart').getContext('2d');
            
            if (this.chart) {
                this.chart.destroy();
            }

            if (stats.length === 0) return;

            this.chart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: stats.map(stat => stat.category),
                    datasets: [{
                        data: stats.map(stat => stat.total),
                        backgroundColor: stats.map(stat => stat.color),
                        borderWidth: 2,
                        borderColor: '#fff'
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        title: {
                            display: true,
                            text: 'Expenses by Category'
                        },
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        } catch (error) {
            console.error('Error updating chart:', error);
        }
    }
}

// Initialize the app
const expenseTracker = new ExpenseTracker();`